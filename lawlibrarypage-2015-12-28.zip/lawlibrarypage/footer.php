	</div>


	
	
	
	
</div><!-- end div pagecontents -->

</div><!-- end div wrap -->

<div class="top-bottom-row-div lawfooter">
	<table cellpadding="0" cellspacing="0" border="0" id="FooterTbl" class="template-block">
		<tr>
			<td id="FooterTdLeft" class="footer-td">
				<a href="https://lawhome.case.edu" target="_blank" class="footer-link">Intranet</a>
			</td>
			<td id="FooterTdRight" class="footer-td" align="right">
				&copy; 2011 Case Western Reserve University School of Law
			</td>
		</tr>
	</table>
</div>

<?php wp_footer(); ?>
</body>
</html>