
<?php get_header(); ?>




        <div id="frontmaincontent">


        

        <div id="corecontent" class="widecolumn">


<p><h2>I'm sorry. We don't have any content for this URL!</h2></p>
<p>This has resulted in a "404" error.  If you arrived at this page from a link on a library or lawschool website, or a link we have provided via email, printed brochure, Facebook, etc. PLEASE let us know at lawref@case.edu and we will both point you in the right direction and fix the error in our communications.</p>
<p>However you arrived here, please use the search box at the top left and/or the navigational menu in the left sidebar to find the content you were seeking.</p>




	</div><!-- end div corecontent -->
	</div>
	

<div id="leftsidebarfrontblog">
<?php get_sidebar('left'); ?></div> <!-- ends div that positions the left sidebar correctly for this page -->

<?php get_sidebar('right'); ?>
<?php get_footer(); ?>