<div id="mainmenubar" class="side left">

<div id="search">
			<h2><?php _e("Search Library Site"); ?></h2>
			<?php get_search_form(); ?>
		</div>

<div id="sidemenu"><?php wp_nav_menu (array('theme_location' => 'main_menu')); ?></div>


<div class="loginStatusContainer">

		</div>

<div id="featurebox">  </div>

</div>